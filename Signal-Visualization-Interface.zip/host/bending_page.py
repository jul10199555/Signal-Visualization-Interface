# ============================================================
# UI: bending_page.py — PC Interface (CustomTkinter) / Python
# Target firmware: Raspberry Pi Pico (RP2040) / MicroPython
#
# Serial protocol / Handshake:
#   PC -> "0\n"  | Pico -> "0\n"  | luego imprime "READY\n"
# RX formats:
#   - Plain text: READY, RUN, STOP, PAUSE, CALIBRANDO, CALIBRACION LISTA, ERROR...
#   - Data frames (Python-list style):
#       ["modo", X, "velocity", v, "angle", a, "resistance", hx_raw]
#   - IDLE continuous resistance (firmware):
#       ["resistance", hx_raw]
#     (sin modo/velocity/angle). La UI debe mantener el último valor mostrado.
#
# Version:      v1.0.2
# Build date:   2026-03-01
# Build time:   15:00:00 (America/Merida)
#
# Changelog:
# - v1.0.2:
#   * Se elimina sección Wheatstone Bridge.
#   * Nueva sección: "Interpretación de Resistencia" (divisor simple):
#       - Selección por radio: "Resistencia de referencia: arriba / abajo"
#   * Por ahora la UI muestra únicamente el valor crudo recibido (RAW).
# ============================================================

import customtkinter as ctk
import threading
import time
import json
import ast
import csv
from datetime import datetime
from tkinter import filedialog  # diálogo para guardar CSV

# === Matplotlib embebido ===
try:
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    _HAS_MPL = True
except Exception:
    _HAS_MPL = False

from serial_interface import SerialInterface

# === presetsBending ===
import presetsBending  # importamos tus presetsBending .py


class BendingPage(ctk.CTkFrame):
    def __init__(self, master, serial_interface: SerialInterface, on_back):
        super().__init__(master)
        self.serial_interface = serial_interface
        self.on_back = on_back

        # Estado de lectura
        self.reader_thread = None
        self.stop_event = threading.Event()
        self.listening = False

        # ===== Logging/mediciones =====
        self.logging_active = False        # se activa tras la PRIMERA muestra válida recibida
        self.log_start_ts = None           # epoch relativo inicio (perf_counter)
        # filas: [t_rel, velocity, angle, resistance]
        self.data_rows = []
        self.expected_modo = 1             # modo esperado según selección UI
        self.log_lock = threading.Lock()   # acceso thread-safe al buffer

        # ===== Plot en vivo =====
        self.LIVE_REFRESH_MS = 250         # intervalo de refresco (ms)
        self.live_enabled = False
        self.live_job = None
        self.plot_x_name = "tiempo"
        self.plot_y_name = "angulo"

        # refs matplotlib
        self._mpl_canvas = None
        self._mpl_fig = None
        self._mpl_ax = None
        self._mpl_line = None

        # ===== Estado de modo activo y calibración =====
        self.mode_running = False
        self.calibrating = False

        # Para debug/visualización
        self.last_hx_value = None   # último valor recibido en campo 'resistance' (RAW u otro)
        self.last_rx_ts = None      # time.perf_counter() cuando llegó el último frame de resistencia

        # ===== Layout base =====
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # ---- Título ----
        title = ctk.CTkLabel(self, text="Bending", font=("Helvetica", 22, "bold"))
        title.grid(row=0, column=0, sticky="ew", padx=20, pady=(24, 8))

        # ---- Área scrolleable ----
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 10))

        # Contenedor del formulario
        self.form = ctk.CTkFrame(self.scroll, fg_color="transparent")
        self.form.pack(fill="x", pady=8)

        # ====== Selector de Mode ======
        mode_row = ctk.CTkFrame(self.form, fg_color="transparent")
        mode_row.pack(fill="x", pady=(8, 4))

        ctk.CTkLabel(mode_row, text="Mode:", font=("Helvetica", 14, "bold")).pack(
            side="left", padx=(0, 10)
        )

        self.mode_values = ["Mode 1", "Mode 2", "Mode 3", "Mode 4"]
        self.mode_texts = {
            "Mode 1": "Modo 1:\nVelocidad Constante\nÁngulo Constante.",
            "Mode 2": "Modo 2:\nVelocidad Constante\nÁngulo Variable.",
            "Mode 3": "Modo 3:\nVelocidad Variable\nÁngulo Constante.",
            "Mode 4": "Modo 4:\nVelocidad Variable\nÁngulo Variable.",
        }

        self.mode_combo = ctk.CTkComboBox(
            mode_row, values=self.mode_values, command=self._on_mode_change, width=180
        )
        self.mode_combo.set("Mode 1")
        self.mode_combo.pack(side="left")

        # === presetsBending: UI ===
        preset_row = ctk.CTkFrame(self.form, fg_color="transparent")
        preset_row.pack(fill="x", pady=(6, 6))

        ctk.CTkLabel(preset_row, text="Preset:", font=("Helvetica", 14, "bold")).pack(
            side="left", padx=(0, 10)
        )
        self.preset_combo = ctk.CTkComboBox(preset_row, values=[], width=260)
        self.preset_combo.pack(side="left")

        self.preset_apply_btn = ctk.CTkButton(
            preset_row, text="Aplicar", width=90, command=self._apply_selected_preset
        )
        self.preset_apply_btn.pack(side="left", padx=(8, 0))

        self.preset_save_btn = ctk.CTkButton(
            preset_row, text="Guardar actual…", width=130, command=self._save_current_as_preset
        )
        self.preset_save_btn.pack(side="left", padx=8)

        self.preset_delete_btn = ctk.CTkButton(
            preset_row, text="Eliminar", width=100, fg_color="#b33",
            command=self._delete_selected_preset
        )
        self.preset_delete_btn.pack(side="left", padx=8)

        # Cargar lista de presetsBending
        self._reload_presetsBending()

        # Descripción dinámica
        desc_frame = ctk.CTkFrame(self.form, fg_color="transparent")
        desc_frame.pack(fill="x", pady=(8, 12))
        self.mode_desc = ctk.CTkLabel(
            desc_frame,
            text=self.mode_texts["Mode 1"],
            justify="left",
            anchor="w",
            font=("Helvetica", 13),
        )
        self.mode_desc.pack(fill="x")

        # ============================================================
        # (NUEVO) Interpretación de Resistencia (divisor simple)
        # Por ahora SOLO selector (radio) y NO cambia el cálculo aún.
        # ============================================================
        self.interp_frame = ctk.CTkFrame(self.form, fg_color="transparent")
        self.interp_frame.pack(fill="x", pady=(2, 12))

        ctk.CTkLabel(
            self.interp_frame,
            text="Interpretación de Resistencia (Divisor simple)",
            font=("Helvetica", 14, "bold")
        ).pack(anchor="w", pady=(0, 6))

        interp_row = ctk.CTkFrame(self.interp_frame, fg_color="transparent")
        interp_row.pack(fill="x", pady=2)

        ctk.CTkLabel(interp_row, text="Resistencia de referencia:").pack(side="left", padx=(0, 10))

        # Radio (solo una opción seleccionable)
        self.ref_pos_var = ctk.StringVar(value="arriba")  # default

        self.ref_top_radio = ctk.CTkRadioButton(
            interp_row, text="Arriba", variable=self.ref_pos_var, value="arriba",
            command=self._on_interp_changed
        )
        self.ref_top_radio.pack(side="left", padx=(0, 12))

        self.ref_bottom_radio = ctk.CTkRadioButton(
            interp_row, text="Abajo", variable=self.ref_pos_var, value="abajo",
            command=self._on_interp_changed
        )
        self.ref_bottom_radio.pack(side="left", padx=(0, 12))

        self.interp_hint = ctk.CTkLabel(
            self.interp_frame,
            text=(
                "Nota:\n"
                "  Por ahora la UI muestra el valor crudo (RAW) recibido en ['resistance', RAW].\n"
                "  Este selector se usará después para invertir/interpretar divisor (Rref arriba/abajo).\n"
            ),
            text_color="#999999",
            justify="left"
        )
        self.interp_hint.pack(anchor="w", pady=(6, 0))

        # ====== Sección dinámica: 2 columnas (Ángulo / Velocidad) ======
        self.two_col = ctk.CTkFrame(self.form, fg_color="transparent")
        self.two_col.pack(fill="x", pady=(4, 10))

        self.left_col = ctk.CTkFrame(self.two_col, fg_color="transparent")
        self.right_col = ctk.CTkFrame(self.two_col, fg_color="transparent")

        self.left_col.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.right_col.pack(side="left", fill="x", expand=True, padx=(8, 0))

        ctk.CTkLabel(self.left_col, text="Ángulo (°)", font=("Helvetica", 15, "bold")).pack(
            anchor="w", pady=(0, 6)
        )
        ctk.CTkLabel(self.right_col, text="Velocidad (rpm)", font=("Helvetica", 15, "bold")).pack(
            anchor="w", pady=(0, 6)
        )

        self.inputs = {}
        self.errors = {}
        self._build_mode_specific_fields("Mode 1")

        # — Sección Restricciones —
        self.rules = ctk.CTkFrame(self.form, fg_color="transparent")
        self.rules.pack(fill="x", pady=(8, 12))
        self._render_rules_text()

        # — Sección Lectura (SIEMPRE VISIBLE) —
        self.read_frame = ctk.CTkFrame(self.form, fg_color="transparent")
        self.read_section_shown = False
        self._build_read_section()
        self.read_section_shown = True

        # — Botonera —
        submit_row = ctk.CTkFrame(self.form, fg_color="transparent")
        submit_row.pack(fill="x", pady=(6, 8))

        self.status_label = ctk.CTkLabel(submit_row, text="", text_color="#999999")
        self.status_label.pack(side="right", padx=8)

        self.submit_btn = ctk.CTkButton(
            submit_row, text="Submit", command=self._on_submit, width=110
        )
        self.submit_btn.pack(side="left", pady=4, padx=(0, 6))

        self.pause_btn = ctk.CTkButton(
            submit_row, text="Pause", command=self._on_pause, width=90, fg_color="#888"
        )
        self.pause_btn.pack(side="left", pady=4, padx=6)

        self.stop_btn = ctk.CTkButton(
            submit_row, text="Stop", command=self._on_stop, width=90, fg_color="#b33"
        )
        self.stop_btn.pack(side="left", pady=4, padx=6)

        self.export_btn = ctk.CTkButton(
            submit_row, text="Export CSV", command=self._on_export_csv,
            width=110, fg_color="#2c7a7b"
        )
        self.export_btn.pack(side="left", pady=4, padx=6)

        # ====== Controles manuales HOME / ENDPOS / CALIBRACION / GOTO ======
        self.manual_frame = ctk.CTkFrame(submit_row, fg_color="transparent")
        self.manual_frame.pack(side="left", padx=(16, 0))

        self.home_btn = ctk.CTkButton(
            self.manual_frame, text="HOME", width=70, command=self._on_home
        )
        self.home_btn.pack(side="left", padx=3)

        self.endpos_btn = ctk.CTkButton(
            self.manual_frame, text="ENDPOS", width=80, command=self._on_endpos
        )
        self.endpos_btn.pack(side="left", padx=3)

        self.calib_btn = ctk.CTkButton(
            self.manual_frame, text="CALIBRACIÓN", width=110,
            command=self._on_calibration
        )
        self.calib_btn.pack(side="left", padx=3)

        self.goto_angle_entry = ctk.CTkEntry(
            self.manual_frame, width=60, placeholder_text="Ángulo"
        )
        self.goto_angle_entry.pack(side="left", padx=(8, 3))

        self.goto_btn = ctk.CTkButton(
            self.manual_frame, text="GOTO", width=60, command=self._on_goto
        )
        self.goto_btn.pack(side="left", padx=3)

        # Mensaje grande de CALIBRANDO debajo de los botones
        self.calib_label = ctk.CTkLabel(
            self.form,
            text="",
            font=("Helvetica", 18, "bold"),
            text_color="#ffcc00",
            anchor="center",
            justify="center",
        )
        self.calib_label.pack(fill="x", pady=(4, 4))

        # ---- Barra inferior ----
        bottom_bar = ctk.CTkFrame(self, fg_color="transparent")
        bottom_bar.grid(row=2, column=0, sticky="ew", padx=20, pady=(0, 18))
        bottom_bar.grid_columnconfigure(0, weight=1)
        self.back_btn = ctk.CTkButton(
            bottom_bar, text="⟵ Regresar", command=self._go_back,
            width=140, fg_color="#444", text_color="white"
        )
        self.back_btn.pack(side="left")

        # ====== Sección de Gráfica ======
        self.plot_section = ctk.CTkFrame(self.scroll, fg_color="transparent")
        self.plot_controls = ctk.CTkFrame(self.plot_section, fg_color="transparent")
        self.plot_controls.pack(fill="x", pady=(10, 6))

        ctk.CTkLabel(
            self.plot_controls, text="X:", font=("Helvetica", 13, "bold")
        ).pack(side="left", padx=(0, 6))
        self.param_options = ["tiempo", "resistencia", "angulo", "velocidad"]
        self.combo_x = ctk.CTkComboBox(
            self.plot_controls, values=self.param_options, width=150,
            command=self._on_param_changed
        )
        self.combo_x.set(self.plot_x_name)
        self.combo_x.pack(side="left", padx=(0, 12))

        ctk.CTkLabel(
            self.plot_controls, text="Y:", font=("Helvetica", 13, "bold")
        ).pack(side="left", padx=(0, 6))
        self.combo_y = ctk.CTkComboBox(
            self.plot_controls, values=self.param_options, width=150,
            command=self._on_param_changed
        )
        self.combo_y.set(self.plot_y_name)
        self.combo_y.pack(side="left", padx=(0, 12))

        self.live_switch = ctk.CTkSwitch(
            self.plot_controls, text="Live", command=self._toggle_live
        )
        self.live_switch.select()
        self.live_switch.pack(side="left", padx=(8, 0))

        self.plot_canvas_container = ctk.CTkFrame(self.plot_section, fg_color="transparent")
        self.plot_canvas_container.pack(fill="both", expand=True)

        if not _HAS_MPL:
            warn = ctk.CTkLabel(
                self.plot_canvas_container,
                text="Matplotlib no está disponible. Instálalo para ver gráficas.",
                text_color="#ff6666",
            )
            warn.pack(pady=8, padx=8, anchor="w")

        # Inicializar estados
        self._update_controls_state()
        self._set_status("UI lista. Esperando datos (resistance en IDLE) / Submit / Calibración.")

        # >>> Lectura permanente: iniciar lector desde el inicio <<<
        self._start_reader()

    # ===================== Interpretación (placeholder) =====================
    def _on_interp_changed(self):
        # Por ahora no cambia cálculo; solo feedback
        pos = self.ref_pos_var.get()
        self._set_status(f"Interpretación: Rref {pos} (por ahora solo RAW).")

        # Re-mostrar el último RAW (si existe)
        if self.last_hx_value is not None:
            self._update_resistance_only(self.last_hx_value)

    # ===================== Helpers de Serial =====================
    def _is_serial_ready(self) -> bool:
        try:
            si = self.serial_interface
            if si is None:
                return False
            ser = getattr(si, "ser", None)
            return ser is not None
        except Exception:
            return False

    def _ensure_serial_ready(self) -> bool:
        if self._is_serial_ready():
            return True
        si = self.serial_interface
        if si is None:
            self._set_status("SerialInterface no inyectado.")
            return False
        connect = getattr(si, "connect", None)
        if callable(connect):
            try:
                port = getattr(si, "port", None) or getattr(si, "device", None)
                baud = getattr(si, "baudrate", None) or 115200
                if port:
                    self._set_status(f"Intentando conectar a {port} @ {baud}...")
                    connect(port, baud)
                    if self._is_serial_ready():
                        self._set_status(f"Conectado a {port}.")
                        return True
                    else:
                        self._set_status("No se pudo establecer la conexión (si.ser sigue vacío).")
                        return False
                else:
                    self._set_status("No hay puerto configurado en SerialInterface (si.port).")
                    return False
            except Exception as e:
                self._set_status(f"Fallo al conectar: {e}")
                return False
        self._set_status("Serial no disponible (falta conexión).")
        return False

    # ===================== Modo dinámico =====================
    def _on_mode_change(self, choice: str):
        self.mode_desc.configure(text=self.mode_texts.get(choice, ""))
        self._build_mode_specific_fields(choice)

    def _reset_inputs(self):
        self.inputs.clear()
        self.errors.clear()

    def _add_labeled_entry(self, parent: ctk.CTkFrame, label: str, placeholder: str = "", width: int = 120):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=4)
        ctk.CTkLabel(row, text=label).pack(side="left", padx=(0, 8))
        entry = ctk.CTkEntry(row, width=width, placeholder_text=placeholder)
        entry.pack(side="left")
        err = ctk.CTkLabel(parent, text="", text_color="#ff6666", font=("Helvetica", 11))
        err.pack(anchor="w", pady=(2, 0))
        return entry, err

    def _build_mode_specific_fields(self, mode: str):
        for w in self.left_col.winfo_children()[1:]:
            w.destroy()
        for w in self.right_col.winfo_children()[1:]:
            w.destroy()
        self._reset_inputs()

        # Ángulo
        if mode in ("Mode 1", "Mode 3"):
            ang_cte, err = self._add_labeled_entry(self.left_col, "Ángulo:", "0–90")
            self.inputs["angle_const"] = ang_cte
            self.errors["angle_const"] = err
        else:
            ang_i, err_i = self._add_labeled_entry(self.left_col, "Ángulo Inicial:", "0–90")
            ang_f, err_f = self._add_labeled_entry(self.left_col, "Ángulo Final:", "0–90")
            ang_s, err_s = self._add_labeled_entry(self.left_col, "Step (Ángulo):", "0–45")
            self.inputs["angle_init"] = ang_i
            self.inputs["angle_final"] = ang_f
            self.inputs["angle_step"] = ang_s
            self.errors["angle_init"] = err_i
            self.errors["angle_final"] = err_f
            self.errors["angle_step"] = err_s

        # Velocidad
        if mode in ("Mode 1", "Mode 2"):
            vel_cte, err = self._add_labeled_entry(self.right_col, "Velocidad:", "7–30")
            self.inputs["speed_const"] = vel_cte
            self.errors["speed_const"] = err
        else:
            vi, err_vi = self._add_labeled_entry(self.right_col, "Velocidad Inicial:", "7–30")
            vf, err_vf = self._add_labeled_entry(self.right_col, "Velocidad Final:", "7–30")
            st, err_st = self._add_labeled_entry(self.right_col, "Step (Velocidad):", "7–30")
            self.inputs["speed_init"] = vi
            self.inputs["speed_final"] = vf
            self.inputs["speed_step"] = st
            self.errors["speed_init"] = err_vi
            self.errors["speed_final"] = err_fv = err_vf
            self.errors["speed_step"] = err_st

    # ======= Texto de reglas =======
    def _render_rules_text(self):
        for w in self.rules.winfo_children():
            w.destroy()
        ctk.CTkLabel(self.rules, text="Restricciones", font=("Helvetica", 14, "bold")).pack(
            anchor="w", pady=(0, 4)
        )
        rules_txt = (
            "• Ángulo: valores enteros entre 0 y 90.\n"
            "• Ángulo variable: el Ángulo Final no puede ser menor que el Inicial.\n"
            "• Step (Ángulo): entero entre 0 y 45.\n"
            "• Velocidad (constante o inicial/final): enteros entre 7 y 30 rpm.\n"
            "• Step (Velocidad): entero entre 7 y 30 rpm.\n"
            "• En Velocidad variable, la inicial puede ser mayor o menor que la final."
        )
        ctk.CTkLabel(self.rules, text=rules_txt, justify="left", anchor="w").pack(anchor="w")

    # ===================== Validaciones =====================
    def _clear_errors(self):
        for lbl in self.errors.values():
            lbl.configure(text="")

    @staticmethod
    def _parse_int(text: str):
        try:
            return int(text.strip())
        except Exception:
            return None

    def _validate(self, mode: str):
        self._clear_errors()
        ok = True
        data = {"modo": self._mode_number(mode)}

        # Ángulo
        if "angle_const" in self.inputs:
            v = self._parse_int(self.inputs["angle_const"].get())
            if v is None or not (0 <= v <= 90):
                self.errors["angle_const"].configure(text="Ángulo debe ser entero entre 0 y 90.")
                ok = False
            else:
                data["angle"] = v
        else:
            a_i = self._parse_int(self.inputs["angle_init"].get())
            a_f = self._parse_int(self.inputs["angle_final"].get())
            a_s = self._parse_int(self.inputs["angle_step"].get())
            if a_i is None or not (0 <= a_i <= 90):
                self.errors["angle_init"].configure(text="Inicial debe ser 0–90.")
                ok = False
            if a_f is None or not (0 <= a_f <= 90):
                self.errors["angle_final"].configure(text="Final debe ser 0–90.")
                ok = False
            if ok and a_f < a_i:
                self.errors["angle_final"].configure(text="El ángulo final no puede ser menor al inicial.")
                ok = False
            if a_s is None or not (0 <= a_s <= 45):
                self.errors["angle_step"].configure(text="Step (Ángulo) debe ser 0–45.")
                ok = False
            if ok:
                data["angle_init"] = a_i
                data["angle_final"] = a_f
                data["angle_step"] = a_s

        # Velocidad
        if "speed_const" in self.inputs:
            v = self._parse_int(self.inputs["speed_const"].get())
            if v is None or not (7 <= v <= 30):
                self.errors["speed_const"].configure(text="Velocidad debe ser un entero entre 7 y 30.")
                ok = False
            else:
                data["speed"] = v
        else:
            v_i = self._parse_int(self.inputs["speed_init"].get())
            v_f = self._parse_int(self.inputs["speed_final"].get())
            st = self._parse_int(self.inputs["speed_step"].get())
            if v_i is None or not (7 <= v_i <= 30):
                self.errors["speed_init"].configure(text="Inicial debe ser 7–30.")
                ok = False
            if v_f is None or not (7 <= v_f <= 30):
                self.errors["speed_final"].configure(text="Final debe ser 7–30.")
                ok = False
            if st is None or not (7 <= st <= 30):
                self.errors["speed_step"].configure(text="Step (Velocidad) debe ser 7–30.")
                ok = False
            if ok:
                data["speed_init"] = v_i
                data["speed_final"] = v_f
                data["speed_step"] = st

        return ok, data

    # ===================== Serial helpers =====================
    @staticmethod
    def _mode_number(mode_name: str) -> int:
        return {"Mode 1": 1, "Mode 2": 2, "Mode 3": 3, "Mode 4": 4}.get(mode_name, 0)

    def _compose_command_json(self, cfg: dict) -> str:
        m = cfg["modo"]
        if m == 1:
            payload = {"modo": 1, "velocity": cfg["speed"], "angle": cfg["angle"]}
        elif m == 2:
            payload = {
                "modo": 2,
                "velocity": cfg["speed"],
                "init_angle": cfg["angle_init"],
                "final_angle": cfg["angle_final"],
                "step_angle": cfg["angle_step"],
            }
        elif m == 3:
            payload = {
                "modo": 3,
                "angle": cfg["angle"],
                "init_vel": cfg["speed_init"],
                "final_vel": cfg["speed_final"],
                "step_vel": cfg["speed_step"],
            }
        elif m == 4:
            payload = {
                "modo": 4,
                "init_angle": cfg["angle_init"],
                "final_angle": cfg["angle_final"],
                "step_angle": cfg["angle_step"],
                "init_vel": cfg["speed_init"],
                "final_vel": cfg["speed_final"],
                "step_vel": cfg["speed_step"],
            }
        else:
            payload = {"modo": 0}
        return json.dumps(payload, separators=(",", ":"))

    # ----- Parsers RX -----
    @staticmethod
    def _parse_kv_list(s: str):
        """
        Parsea frames tipo Python-list: ["k1", v1, "k2", v2, ...]
        Devuelve dict con keys en lower(), o None.
        """
        try:
            lst = ast.literal_eval(s)
            if not isinstance(lst, list):
                return None
            d = {}
            i = 0
            while i + 1 < len(lst):
                k = lst[i]
                v = lst[i + 1]
                if isinstance(k, str):
                    d[k.strip().lower()] = v
                i += 2
            return d
        except Exception:
            return None

    @staticmethod
    def _to_float(x):
        if isinstance(x, (int, float)):
            return float(x)
        if isinstance(x, str):
            x = x.strip()
            try:
                return float(x)
            except Exception:
                return None
        return None

    def _extract_frame(self, raw_line: str):
        """
        Devuelve:
          modo(int|None), velocity(float|None), angle(float|None), resistance(float|None), dict_frame(optional)
        Soporta:
          - ["modo",..,"velocity",..,"angle",..,"resistance",..]
          - ["resistance",..]  (IDLE)
        """
        d = self._parse_kv_list(raw_line)
        if not d:
            return None, None, None, None, None

        res = d.get("resistance", d.get("resistencia"))
        res_val = self._to_float(res) if res is not None else None

        modo = d.get("modo")
        velocity = d.get("velocity", d.get("velocidad"))
        angle = d.get("angle", d.get("angulo"))

        modo_i = None
        try:
            if modo is not None:
                modo_i = int(modo)
        except Exception:
            modo_i = None

        vel_f = self._to_float(velocity) if velocity is not None else None
        ang_f = self._to_float(angle) if angle is not None else None

        return modo_i, vel_f, ang_f, res_val, d

    # ===================== Calibración: control de UI =====================
    def _set_calibrating_ui(self, flag: bool):
        def _do():
            self.calibrating = flag
            if flag:
                self._safe_status_direct("Calibrando... por favor espera.")
                self.calib_label.configure(text="CALIBRANDO...")
            else:
                self.calib_label.configure(text="")
            self._update_controls_state()
        self.after(0, _do)

    def _update_controls_state(self):
        if self.calibrating:
            self.submit_btn.configure(state="disabled")
            self.pause_btn.configure(state="disabled")
            self.export_btn.configure(state="disabled")
            self.stop_btn.configure(state="normal")

            self.mode_combo.configure(state="disabled")
            self.preset_combo.configure(state="disabled")
            self.preset_apply_btn.configure(state="disabled")
            self.preset_save_btn.configure(state="disabled")
            self.preset_delete_btn.configure(state="disabled")

            for w in (self.home_btn, self.endpos_btn, self.calib_btn,
                      self.goto_angle_entry, self.goto_btn):
                w.configure(state="disabled")

            self.live_switch.configure(state="disabled")
            self.combo_x.configure(state="disabled")
            self.combo_y.configure(state="disabled")

            self.back_btn.configure(state="disabled")

            # Interpretación: también bloqueada durante calibración
            try:
                self.ref_top_radio.configure(state="disabled")
                self.ref_bottom_radio.configure(state="disabled")
            except Exception:
                pass
            return

        # No calibrando
        self.submit_btn.configure(state="normal")
        self.pause_btn.configure(state="normal")
        self.export_btn.configure(state="normal")
        self.stop_btn.configure(state="normal")

        self.mode_combo.configure(state="normal")
        self.preset_combo.configure(state="normal")
        self.preset_apply_btn.configure(state="normal")
        self.preset_save_btn.configure(state="normal")
        self.preset_delete_btn.configure(state="normal")

        self.live_switch.configure(state="normal")
        self.combo_x.configure(state="normal")
        self.combo_y.configure(state="normal")

        self.back_btn.configure(state="normal")

        manual_state = "disabled" if self.mode_running else "normal"
        for w in (self.home_btn, self.endpos_btn, self.calib_btn,
                  self.goto_angle_entry, self.goto_btn):
            w.configure(state=manual_state)

        try:
            self.ref_top_radio.configure(state="normal")
            self.ref_bottom_radio.configure(state="normal")
        except Exception:
            pass

    # ===================== Lector RX =====================
    def _start_reader(self):
        if self.listening:
            return
        self.stop_event.clear()
        self.listening = True

        def _worker():
            try:
                if not self._ensure_serial_ready():
                    self.listening = False
                    return
                ser = getattr(self.serial_interface, "ser", None)
                if not ser:
                    self._set_status("Serial no disponible.")
                    self.listening = False
                    return

                self._set_status("Leyendo datos...")

                while not self.stop_event.is_set():
                    raw = self.serial_interface.ser.readline().decode(errors="ignore").strip()
                    if not raw:
                        continue

                    up = raw.upper()

                    # --- Mensajes relacionados con calibración ---
                    if ("CALIBRACION LISTA" in up or
                        "MOTOR EN HOME" in up or
                        "CALIBRADO" in up):
                        self._set_calibrating_ui(False)
                        time.sleep(0.003)
                        continue

                    if ("CALIBRANDO" in up) or (up.strip() == "CALIBRACION"):
                        self._set_calibrating_ui(True)
                        time.sleep(0.003)
                        continue

                    modo, vel, ang, res, d = self._extract_frame(raw)

                    # 1) Siempre: si viene resistance (incluye IDLE), actualizamos display (RAW)
                    if res is not None:
                        self.last_hx_value = res
                        self.last_rx_ts = time.perf_counter()
                        self._update_resistance_only(res)  # <- RAW

                    # 2) Si viene frame completo (modo/vel/ang), además logging + UI completa
                    if (modo is not None) and (vel is not None) and (ang is not None):
                        if modo == self.expected_modo or modo == 0:
                            with self.log_lock:
                                now = time.perf_counter()
                                if not self.logging_active:
                                    self.logging_active = True
                                    self.log_start_ts = now
                                t_rel = now - self.log_start_ts
                                self.data_rows.append([t_rel, float(vel), float(ang), res])

                            self._update_readings(modo, ang, vel, res)

                    time.sleep(0.003)

            except Exception as e:
                self._set_status(f"Error lector: {e}")
            finally:
                self.listening = False

        self.reader_thread = threading.Thread(target=_worker, daemon=True)
        self.reader_thread.start()

    # ===================== Status =====================
    def _safe_status_direct(self, text: str):
        try:
            if hasattr(self, "status_label") and self.status_label is not None:
                self.status_label.configure(text=text)
        except Exception:
            pass

    def _set_status(self, text: str):
        try:
            self.after(0, lambda: self._safe_status_direct(text))
        except Exception:
            self._safe_status_direct(text)

    # ===================== UI updates =====================
    def _format_raw_display(self, raw_value):
        """
        Muestra el RAW recibido en formato humano (sin convertir a Ω todavía).
        """
        if raw_value is None:
            if self.last_hx_value is None:
                return "N/E"
            try:
                return f"N/E (RAW {float(self.last_hx_value):.0f})"
            except Exception:
                return "N/E"

        try:
            rv = float(raw_value)
            # RAW normalmente es entero grande
            if abs(rv) >= 1:
                return f"{rv:.0f}"
            return f"{rv:.6f}"
        except Exception:
            return "N/E"

    def _update_resistance_only(self, raw_value):
        """
        Actualiza únicamente la etiqueta de resistencia (permanente),
        sin depender de modo/vel/ángulo.
        """
        def _do():
            if hasattr(self, "resistance_value_label"):
                self.resistance_value_label.configure(text=self._format_raw_display(raw_value))

        self.after(0, _do)

    def _update_readings(self, mode_val: int, angle_val: float, speed_val: float, resistance_val=None):
        def _do():
            if hasattr(self, "mode_value_label"):
                self.mode_value_label.configure(text=str(mode_val))

            if hasattr(self, "angle_value_label"):
                try:
                    self.angle_value_label.configure(text=f"{float(angle_val):.6f}")
                except Exception:
                    self.angle_value_label.configure(text=str(angle_val))

            if hasattr(self, "speed_value_label"):
                try:
                    sv = float(speed_val)
                    if sv.is_integer():
                        self.speed_value_label.configure(text=str(int(sv)))
                    else:
                        self.speed_value_label.configure(text=f"{sv:.6f}")
                except Exception:
                    self.speed_value_label.configure(text=str(speed_val))

            if hasattr(self, "resistance_value_label"):
                self.resistance_value_label.configure(text=self._format_raw_display(resistance_val))

            if hasattr(self, "samples_label"):
                with self.log_lock:
                    n = len(self.data_rows)
                self.samples_label.configure(text=f"Muestras: {n}")

        self.after(0, _do)

    # ===================== Controles manuales =====================
    def _send_manual_command(self, cmd: str):
        try:
            if not self._ensure_serial_ready():
                return
            if hasattr(self.serial_interface, "send_command") and callable(self.serial_interface.send_command):
                self.serial_interface.send_command(cmd)
            else:
                self.serial_interface.ser.write((cmd + "\n").encode())
            self._set_status(f"{cmd} enviado.")
        except Exception as e:
            self._set_status(f"Error al enviar {cmd}: {e}")

    def _on_home(self):
        if self.mode_running or self.calibrating:
            self._set_status("No se puede usar HOME mientras hay modo activo o calibración.")
            return
        self._send_manual_command("HOME")

    def _on_endpos(self):
        if self.mode_running or self.calibrating:
            self._set_status("No se puede usar ENDPOS mientras hay modo activo o calibración.")
            return
        self._send_manual_command("ENDPOS")

    def _on_calibration(self):
        if self.mode_running or self.calibrating:
            self._set_status("No se puede calibrar mientras hay modo activo o calibración.")
            return
        self._send_manual_command("CALIBRACION")
        self._set_calibrating_ui(True)
        self._start_reader()

    def _on_goto(self):
        if self.mode_running or self.calibrating:
            self._set_status("No se puede usar GOTO mientras hay modo activo o calibración.")
            return
        txt = self.goto_angle_entry.get().strip()
        if not txt:
            self._set_status("Ingresa un ángulo para GOTO.")
            return
        try:
            ang = int(txt)
        except Exception:
            self._set_status("Ángulo inválido para GOTO (usa entero).")
            return
        if not (0 <= ang <= 90):
            self._set_status("Ángulo GOTO debe ser 0–90.")
            return
        cmd = f"GOTO:{ang}"
        self._send_manual_command(cmd)

    # ===================== Acciones =====================
    def _on_submit(self):
        if self.calibrating:
            self._set_status("No puedes iniciar un modo mientras se calibra.")
            return

        mode = self.mode_combo.get()
        ok, cfg = self._validate(mode)
        if not ok:
            return

        self.expected_modo = self._mode_number(mode)
        with self.log_lock:
            self.logging_active = False
            self.log_start_ts = None
            self.data_rows = []

        cmd_str = self._compose_command_json(cfg)
        self._send_submit_command(cmd_str)

        self.mode_running = True
        self._update_controls_state()

        # Asegurar lector activo
        self._start_reader()

        if _HAS_MPL:
            self.plot_section.pack(fill="both", expand=True, pady=(8, 10))
            self.live_enabled = True
            self.live_switch.select()
            self._ensure_plot_initialized()
            self._schedule_live_tick()

    def _send_submit_command(self, cmd_str: str):
        try:
            if not self._ensure_serial_ready():
                return
            if hasattr(self.serial_interface, "send_command") and callable(self.serial_interface.send_command):
                self.serial_interface.send_command(cmd_str)
            else:
                ser = self.serial_interface.ser
                ser.write((cmd_str + "\n").encode())
            self._set_status("Comando enviado.")
        except Exception as e:
            self._set_status(f"Error al enviar: {e}")
            return

    def _on_pause(self):
        if self.calibrating:
            self._set_status("No puedes usar PAUSE durante calibración.")
            return
        try:
            if not self._ensure_serial_ready():
                return
            if hasattr(self.serial_interface, "send_command") and callable(self.serial_interface.send_command):
                self.serial_interface.send_command("PAUSE")
            else:
                self.serial_interface.ser.write(b"PAUSE\n")
            self._set_status("PAUSE enviado.")
        except Exception as e:
            self._set_status(f"Error PAUSE: {e}")

    def _on_stop(self):
        try:
            if self._ensure_serial_ready():
                if hasattr(self.serial_interface, "send_command") and callable(self.serial_interface.send_command):
                    self.serial_interface.send_command("STOP")
                else:
                    self.serial_interface.ser.write(b"STOP\n")
            self._set_status("STOP enviado. Exportando CSV...")

            if self.listening:
                self.stop_event.set()
                if self.reader_thread and self.reader_thread.is_alive():
                    self.reader_thread.join(timeout=0.5)

            self._export_csv()

            with self.log_lock:
                self.logging_active = False
                self.log_start_ts = None

            self.mode_running = False
            self._set_calibrating_ui(False)

            # Reiniciar lector permanente
            self.stop_event.clear()
            self._start_reader()

            self._set_status("CSV exportado.")
        except Exception as e:
            self._set_status(f"Error STOP/CSV: {e}")

    def _on_export_csv(self):
        if self.calibrating:
            self._set_status("No se puede exportar CSV durante calibración.")
            return
        try:
            self._export_csv()
            self._set_status("CSV exportado (manual).")
        except Exception as e:
            self._set_status(f"Error al exportar CSV: {e}")

    def _export_csv(self):
        with self.log_lock:
            rows = list(self.data_rows)

        if not rows:
            self._set_status("No hay datos para exportar.")
            return

        default_name = f"bending_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        try:
            path = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv")],
                initialfile=default_name,
                title="Guardar mediciones como CSV",
            )
        except Exception:
            path = ""

        if not path:
            path = default_name

        rows_to_write = []
        for r in rows:
            r = list(r)
            if len(r) < 4:
                r += [None] * (4 - len(r))
            t, v, a, res = r[:4]
            res_out = "" if res is None else res
            rows_to_write.append([t, v, a, res_out])

        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["time", "velocity", "angle", "resistance_raw"])
                writer.writerows(rows_to_write)
        except Exception as e:
            self._set_status(f"No se pudo guardar CSV: {e}")
            return

    # ===================== Gráfica (en vivo) =====================
    def _on_param_changed(self, _value=None):
        if self.calibrating:
            self._set_status("No se pueden cambiar ejes durante calibración.")
            return
        self.plot_x_name = self.combo_x.get().strip().lower()
        self.plot_y_name = self.combo_y.get().strip().lower()
        if self.plot_x_name == self.plot_y_name:
            self._set_status("X y Y no pueden ser el mismo parámetro.")
            return
        if _HAS_MPL:
            self._ensure_plot_initialized(force_new_axes=True)
            if not self.live_enabled:
                self._live_plot_tick()

    def _toggle_live(self):
        if self.calibrating:
            self._set_status("No se puede activar/desactivar Live durante calibración.")
            return
        self.live_enabled = bool(self.live_switch.get())
        if self.live_enabled:
            if _HAS_MPL:
                self._ensure_plot_initialized()
                self._schedule_live_tick()
            self._set_status("Live ON.")
        else:
            self._stop_live_plot()
            self._set_status("Live OFF.")

    def _ensure_plot_initialized(self, force_new_axes: bool = False):
        if not _HAS_MPL:
            return
        if self._mpl_canvas is None or force_new_axes:
            for w in self.plot_canvas_container.winfo_children():
                w.destroy()

            fig = Figure(figsize=(6, 3.6), dpi=100)
            ax = fig.add_subplot(111)

            (line,) = ax.plot([], [])
            ax.grid(True, linestyle="--", alpha=0.3)

            units = {"tiempo": "s", "velocidad": "rpm", "angulo": "°", "resistencia": "RAW"}

            def label(n):
                base = n.capitalize()
                u = units.get(n, "")
                return f"{base} ({u})" if u else base

            ax.set_xlabel(label(self.plot_x_name))
            ax.set_ylabel(label(self.plot_y_name))
            ax.set_title(f"{label(self.plot_y_name)} vs {label(self.plot_x_name)}")

            canvas = FigureCanvasTkAgg(fig, master=self.plot_canvas_container)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)

            self._mpl_canvas = canvas
            self._mpl_fig = fig
            self._mpl_ax = ax
            self._mpl_line = line
        else:
            ax = self._mpl_ax
            units = {"tiempo": "s", "velocidad": "rpm", "angulo": "°", "resistencia": "RAW"}

            def label(n):
                base = n.capitalize()
                u = units.get(n, "")
                return f"{base} ({u})" if u else base

            ax.set_xlabel(label(self.plot_x_name))
            ax.set_ylabel(label(self.plot_y_name))
            ax.set_title(f"{label(self.plot_y_name)} vs {label(self.plot_x_name)}")

    def _schedule_live_tick(self):
        if self.live_enabled and self.live_job is None:
            self.live_job = self.after(self.LIVE_REFRESH_MS, self._live_plot_tick)

    def _stop_live_plot(self):
        if self.live_job is not None:
            try:
                self.after_cancel(self.live_job)
            except Exception:
                pass
            self.live_job = None

    def _live_plot_tick(self):
        self.live_job = None
        if not self.live_enabled or not _HAS_MPL:
            return

        idx_map = {"tiempo": 0, "velocidad": 1, "angulo": 2, "resistencia": 3}
        x_name = self.plot_x_name
        y_name = self.plot_y_name

        if x_name == y_name or (x_name not in idx_map) or (y_name not in idx_map):
            self._schedule_live_tick()
            return

        with self.log_lock:
            rows = list(self.data_rows)

        if len(rows) >= 2:
            xi, yi = idx_map[x_name], idx_map[y_name]
            valid_pairs = []
            for r in rows:
                r = list(r)
                if len(r) <= max(xi, yi):
                    continue
                vx = r[xi]
                vy = r[yi]
                if vx is None or vy is None:
                    continue
                valid_pairs.append((vx, vy))

            if valid_pairs:
                x = [p[0] for p in valid_pairs]
                y = [p[1] for p in valid_pairs]
            else:
                x, y = [], []
        else:
            x, y = [], []

        self._ensure_plot_initialized()

        if self._mpl_line is not None:
            self._mpl_line.set_data(x, y)
            if len(x) > 0 and len(y) > 0:
                self._mpl_ax.relim()
                self._mpl_ax.autoscale_view()
            self._mpl_canvas.draw_idle()

        self._schedule_live_tick()

    # ===================== UI de lectura =====================
    def _build_read_section(self):
        self.read_frame.pack(fill="x", pady=(12, 6))
        ctk.CTkLabel(self.read_frame, text="Lectura", font=("Helvetica", 16, "bold")).pack(
            anchor="w", pady=(0, 8)
        )
        mode_row = ctk.CTkFrame(self.read_frame, fg_color="transparent")
        mode_row.pack(fill="x", pady=(0, 6))
        ctk.CTkLabel(mode_row, text="Modo", font=("Helvetica", 14, "bold")).pack(side="left")
        self.mode_value_label = ctk.CTkLabel(mode_row, text="--", font=("Helvetica", 18))
        self.mode_value_label.pack(side="left", padx=(8, 0))

        grid = ctk.CTkFrame(self.read_frame, fg_color="transparent")
        grid.pack(fill="x")

        left = ctk.CTkFrame(grid, fg_color="transparent")
        middle = ctk.CTkFrame(grid, fg_color="transparent")
        right = ctk.CTkFrame(grid, fg_color="transparent")

        left.pack(side="left", fill="x", expand=True, padx=(0, 8))
        middle.pack(side="left", fill="x", expand=True, padx=8)
        right.pack(side="left", fill="x", expand=True, padx=(8, 0))

        # Ángulo
        ctk.CTkLabel(left, text="Ángulo (°)", font=("Helvetica", 14, "bold")).pack(anchor="w")
        self.angle_value_label = ctk.CTkLabel(left, text="--", font=("Helvetica", 22))
        self.angle_value_label.pack(anchor="w", pady=(4, 6))

        # Velocidad
        ctk.CTkLabel(middle, text="Velocidad (rpm)", font=("Helvetica", 14, "bold")).pack(anchor="w")
        self.speed_value_label = ctk.CTkLabel(middle, text="--", font=("Helvetica", 22))
        self.speed_value_label.pack(anchor="w", pady=(4, 6))

        # Resistencia (RAW)
        ctk.CTkLabel(right, text="Resistencia (RAW)", font=("Helvetica", 14, "bold")).pack(anchor="w")
        self.resistance_value_label = ctk.CTkLabel(right, text="N/E", font=("Helvetica", 22))
        self.resistance_value_label.pack(anchor="w", pady=(4, 6))

        self.samples_label = ctk.CTkLabel(self.read_frame, text="Muestras: 0", font=("Helvetica", 12))
        self.samples_label.pack(anchor="w", pady=(6, 0))

    def _go_back(self):
        if self.listening:
            self.stop_event.set()
        self._stop_live_plot()
        self.mode_running = False
        self._set_calibrating_ui(False)
        if callable(self.on_back):
            self.on_back()

    # ===================== presetsBending: lógica =====================
    def _reload_presetsBending(self):
        self._all_presetsBending = presetsBending.load_all()
        names = list(self._all_presetsBending.keys())
        if not names:
            names = [""]
        self.preset_combo.configure(values=names)
        if names:
            self.preset_combo.set(names[0])

    def _apply_selected_preset(self):
        name = self.preset_combo.get().strip()
        if not name or name not in self._all_presetsBending:
            self._set_status("Selecciona un preset válido.")
            return
        cfg = self._all_presetsBending[name]
        self._apply_preset_cfg(cfg)
        self._set_status(f"Preset aplicado: {name}")

    def _apply_preset_cfg(self, cfg: dict):
        modo = int(cfg.get("modo", 0))

        name_by_mode = {1: "Mode 1", 2: "Mode 2", 3: "Mode 3", 4: "Mode 4"}.get(modo, "Mode 1")
        if self.mode_combo.get() != name_by_mode:
            self.mode_combo.set(name_by_mode)
            self._on_mode_change(name_by_mode)

        def set_entry(key: str, value):
            if key in self.inputs and hasattr(self.inputs[key], "delete"):
                self.inputs[key].delete(0, "end")
                self.inputs[key].insert(0, str(value))

        if modo == 1:
            if "angle" in cfg:
                set_entry("angle_const", cfg["angle"])
            if "speed" in cfg:
                set_entry("speed_const", cfg["speed"])
        elif modo == 2:
            if "init_angle" in cfg:
                set_entry("angle_init", cfg["init_angle"])
            if "final_angle" in cfg:
                set_entry("angle_final", cfg["final_angle"])
            if "step_angle" in cfg:
                set_entry("angle_step", cfg["step_angle"])
            if "velocity" in cfg:
                set_entry("speed_const", cfg["velocity"])
        elif modo == 3:
            if "angle" in cfg:
                set_entry("angle_const", cfg["angle"])
            if "init_vel" in cfg:
                set_entry("speed_init", cfg["init_vel"])
            if "final_vel" in cfg:
                set_entry("speed_final", cfg["final_vel"])
            if "step_vel" in cfg:
                set_entry("speed_step", cfg["step_vel"])
        elif modo == 4:
            if "init_angle" in cfg:
                set_entry("angle_init", cfg["init_angle"])
            if "final_angle" in cfg:
                set_entry("angle_final", cfg["final_angle"])
            if "step_angle" in cfg:
                set_entry("angle_step", cfg["step_angle"])
            if "init_vel" in cfg:
                set_entry("speed_init", cfg["init_vel"])
            if "final_vel" in cfg:
                set_entry("speed_final", cfg["final_vel"])
            if "step_vel" in cfg:
                set_entry("speed_step", cfg["step_vel"])

    def _save_current_as_preset(self):
        mode = self.mode_combo.get()
        ok, cfg = self._validate(mode)
        if not ok:
            self._set_status("Corrige los errores antes de guardar el preset.")
            return

        m = cfg["modo"]
        if m == 1:
            store = {"modo": 1, "angle": cfg["angle"], "speed": cfg["speed"]}
        elif m == 2:
            store = {
                "modo": 2,
                "velocity": cfg["speed"],
                "init_angle": cfg["angle_init"],
                "final_angle": cfg["angle_final"],
                "step_angle": cfg["angle_step"],
            }
        elif m == 3:
            store = {
                "modo": 3,
                "angle": cfg["angle"],
                "init_vel": cfg["speed_init"],
                "final_vel": cfg["speed_final"],
                "step_vel": cfg["speed_step"],
            }
        else:
            store = {
                "modo": 4,
                "init_angle": cfg["angle_init"],
                "final_angle": cfg["angle_final"],
                "step_angle": cfg["angle_step"],
                "init_vel": cfg["speed_init"],
                "final_vel": cfg["speed_final"],
                "step_vel": cfg["speed_step"],
            }

        def _commit():
            name = entry.get().strip()
            prompt.destroy()
            try:
                if presetsBending.is_builtin(name):
                    self._set_status("No se puede sobreescribir un preset base. Usa otro nombre.")
                    return
                presetsBending.save_user_preset(name, store)
                self._reload_presetsBending()
                self.preset_combo.set(name)
                self._set_status(f"Preset guardado: {name}")
            except Exception as e:
                self._set_status(f"No se pudo guardar: {e}")

        prompt = ctk.CTkToplevel(self)
        prompt.title("Guardar preset")
        ctk.CTkLabel(prompt, text="Nombre del preset:").pack(padx=16, pady=(16, 6))
        entry = ctk.CTkEntry(prompt, width=280, placeholder_text="Ej. Mi preset M1 @10° 7rpm")
        entry.pack(padx=16, pady=6)
        btns = ctk.CTkFrame(prompt, fg_color="transparent")
        btns.pack(pady=(6, 16))
        ctk.CTkButton(btns, text="Guardar", command=_commit).pack(side="left", padx=8)
        ctk.CTkButton(btns, text="Cancelar", fg_color="#777", command=prompt.destroy).pack(side="left", padx=8)

        prompt.geometry("+200+150")
        entry.focus_set()

    def _delete_selected_preset(self):
        name = self.preset_combo.get().strip()
        if not name:
            self._set_status("Selecciona un preset.")
            return
        if presetsBending.is_builtin(name):
            self._set_status("No se puede eliminar un preset base.")
            return
        ok = presetsBending.delete_user_preset(name)
        if ok:
            self._reload_presetsBending()
            self._set_status(f"Preset eliminado: {name}")
        else:
            self._set_status("Ese preset no existe en el almacenamiento de usuario.")